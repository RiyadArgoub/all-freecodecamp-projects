const dns = require("dns");
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require("body-parser");
// const validUrl = require('valid-url');

const app = express();

// Basic Configuration
const port = process.env.PORT || 3000;

app.use(cors());
app.use('/public', express.static(`${process.cwd()}/public`));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.sendFile(process.cwd() + '/views/index.html');
});

// Your first API endpoint
// app.get('/api/hello', (req, res) => {
//   res.json({ greeting: 'hello API' });
// });

const urls = [];

app.post("/api/shorturl", (req, res) => {
  const url = req.body.url;
  let response;

  // if (validUrl.isUri(url)) {
  if (/https?.+/.test(url)) {
    urls.push(url);

    response = {
      original_url: url,
      short_url: urls.length
    };
  } else {
    response = { error: 'invalid url' };
  }

  console.log(url);
  console.log(response);

  res.json(response);
});

app.use("/api/shorturl/:short_url", (req, res) => {
  res.redirect(urls[+req.params.short_url - 1]);
});

app.listen(port, function() {
  console.log(`Listening on port ${port}`);
});