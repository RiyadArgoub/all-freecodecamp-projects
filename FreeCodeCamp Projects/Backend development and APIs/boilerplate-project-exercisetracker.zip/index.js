const express = require('express');
const bodyParser = require("body-parser");
const app = express();
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

app.use(cors());
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (_req, res) => {
  res.sendFile(__dirname + '/views/index.html');
});

const users = [];
const exercises = [];
const logs = [];

app.post("/api/users", (req, res) => {
  const username = req.body.username;

  const newUser = { _id: uuidv4(), username };
  users.push(newUser);
  logs.push({...newUser, count: 0, log: []});

  res.json(newUser);
});

app.get("/api/users", (req, res) => {
  res.send(
    users.map(({ _id, username }) => ({ _id, username })
  ));
});

app.post("/api/users/:_id/exercises", (req, res) => {
  const { _id } = req.params;
  const { description, duration, date } = req.body;

  const user = users.find((user) => user._id === _id);

  const newExercise = {
    ...user,
    description,
    duration: +duration,
    date: date ? new Date(date).toDateString() : new Date().toDateString()
  };
  exercises.push(newExercise);
  const log = logs.find(log => log._id === _id)
  log.count++;
  log.log.push({
    description,
    duration: +duration,
    date: date ? new Date(date).toDateString() : new Date().toDateString()
  })

  res.json(newExercise);
});

app.get("/api/users/:_id/logs?", (req, res) => {
  const { _id } = req.params;
  const { from, to, limit } = req.query;

  console.log("==================")
  console.log(from);
  console.log(to);
  console.log(limit);

  let log = logs.find(log => log._id === _id)

  console.log("INITIAL LOG")
  console.log(log);

  if(from || to || limit) {
    log = JSON.parse(JSON.stringify(log));
    
    if(from && to)
      log.log = log.log
        .filter(({ date }) => {
          console.log("------------------")
          console.log("DATE TO FILTER")
          console.log(date);
          const dateObj = new Date(date);
          const cond = +dateObj >= +(new Date(from)) &&
            +dateObj <= +(new Date(to));
          console.log("CONDIION")
          console.log(cond);
          console.log("------------------")
          return cond;
        })

    if(limit)
      log.log = log.log.slice(0, +limit);

    console.log("FINAL LOG")
    console.log(log);
    console.log("==================")

    log.count = log.log.length;
  }

  res.json(log);
});

const listener = app.listen(process.env.PORT || 3000, () => {
  console.log('Your app is listening on port ' + listener.address().port)
})