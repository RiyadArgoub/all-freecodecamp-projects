// server.js
// where your node app starts

// init project
const express = require('express');
const app = express();

// enable CORS (https://en.wikipedia.org/wiki/Cross-origin_resource_sharing)
// so that your API is remotely testable by FCC 
const cors = require('cors');
app.use(cors({optionsSuccessStatus: 200}));  // some legacy browsers choke on 204

// http://expressjs.com/en/starter/static-files.html
app.use(express.static('public'));

// http://expressjs.com/en/starter/basic-routing.html
app.get("/", (req, res) => {
  res.sendFile(__dirname + '/views/index.html');
});

// your first API endpoint... 
// app.get("/api/hello", (req, res) => {
//   res.json({greeting: 'hello API'});
// });

const isEmpty = (dateParam) => {
  // return dateParam === "" || dateParam === null || dateParam === undefined;
  return !dateParam;
}

const isValidTimestamp = (dateParam) => {
  return !isNaN(dateParam);
}

const isValidDate = (dateParam) => {
  // const tempDateArr = dateParam.split("-");

  // return tempDateArr.length === 3 &&
  //   tempDateArr.every(el => Number.isInteger(+el));

  // new Date(dateParam).toString() !== "Invalid Date";

  return !(new Date(dateParam).toString() === "Invalid Date" &&
      new Date(+dateParam).toString() === "Invalid Date");
}

const getResult = (date) => {
  const unix = date.getTime();
  const _ = date.toString().substring(0, 28).split(" ");
  const utc = `${_[0]}, ${_[2]} ${_[1]} ${_[3]} ${_[4]} ${_[5]}`;

  return { unix, utc };
}

app.get("/api/", (req, res) => {
    const date = new Date();
    // date.setMinutes(date.getMinutes() - 3)
    const result = getResult(date);
    console.log("BR 01");
    console.log(result);
    res.json(result);
});

app.get("/api/:date?", (req, res) => {
  const dateParam = req.params.date;
  
  let date;
  
  if(isEmpty(dateParam)) {
    date = new Date();
    date.setMinutes(date.getMinutes() - 3)
    const result = getResult(date);
    console.log("BR 01");
    console.log(result);
    res.json(result);
  } else if(isValidDate(dateParam)) {
    if(isNaN(dateParam))
      date = new Date(dateParam);
    else
      date = new Date(+dateParam);
    console.log("BR 02");
    const result = getResult(date);
    console.log(result);
    res.json(result);
  } else {
    const result = { error : "Invalid Date" };
    console.log("BR 03");
    console.log(result);
    res.json(result);
  }
});

// listen for requests :)
const listener = app.listen(process.env.PORT, () => {
  console.log('Your app is listening on port ' + listener.address().port);
});