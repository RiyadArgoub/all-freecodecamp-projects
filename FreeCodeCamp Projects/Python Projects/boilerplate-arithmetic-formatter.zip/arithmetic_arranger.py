def arithmetic_arranger(*problems):
  if len(problems[0]) > 5:
    return "Error: Too many problems."
  row1 = []
  signs = []
  row2 = []
  lignrow = []
  finalrow = []
  sentence=""
  for i in range(len(problems[0])):
    problems[0][i]=problems[0][i].split(" ")
    row1.append(problems[0][i][0])
    signs.append(problems[0][i][1])
    row2.append(problems[0][i][2])
  for i in range(len(signs)):
    if signs[i]=="+" or signs[i]=="-":
      continue
    else:
      return "Error: Operator must be '+' or '-'."
  for i in range(len(row2)):
    try:
      if int(row1[i])>9999 or int(row2[i])>9999:
        return "Error: Numbers cannot be more than four digits."
      else:
        if signs[i]=="+":
          finalrow.append(int(row1[i])+int(row2[i]))
        elif signs[i]=="-":
          finalrow.append(int(row1[i])-int(row2[i]))
    except:
      return "Error: Numbers must only contain digits."
  for i in range(len(row2)):
    lignrow.append(max(len(row1[i]),len(row2[i])))
  for i in range(len(problems[0])):
    for j in range(lignrow[i]-len(row1[i])+2):
      sentence= sentence + " "
    sentence= sentence + row1[i]
    if i==len(problems[0])-1:
      sentence= sentence + "\n"
    else:
      sentence= sentence + "    "
  for i in range(len(problems[0])):
    sentence= sentence + signs[i]
    for j in range(lignrow[i]-len(row2[i])+1):
      sentence= sentence + " "
    sentence= sentence + row2[i]
    if i==len(problems[0])-1:
      sentence= sentence + "\n"
    else:
      sentence= sentence + "    "
  for i in range(len(problems[0])):
    for j in range(lignrow[i]+2):
      sentence= sentence + "-"
    if i==len(problems[0])-1:
      try:
        if problems[1]==True:
          sentence= sentence + "\n"
        else:
          pass
      except:
        pass
    else:
      sentence= sentence + "    "
  if len(problems) != 2:
    return sentence
  else:
    for i in range(len(problems[0])):
      for j in range(lignrow[i]-len(str(finalrow[i]))+2):
        sentence= sentence + " "
      sentence= sentence + str(finalrow[i])
      if i==len(problems[0])-1:
        continue
      else:
        sentence= sentence + "    "
  print(sentence)
  return sentence