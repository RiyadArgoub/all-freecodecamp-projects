import copy
import random
# Consider using the modules imported above.

class Hat:
  def __init__(self,**balls):
    self.contents=[]
    self.list=["blue","yellow","red","orange","pink","striped","green","black","test"]
    for i in range (8):
      try:
        for j in range(balls[self.list[i]]):
          self.contents.insert(0,self.list[i])
      except:
        pass
    self.contentsCopy= copy.deepcopy(self.contents)
    self.holder=copy.deepcopy(self.contents)
  def draw(self,number):
    self.contents=copy.deepcopy(self.contentsCopy)
    self.drawn=[]
    self.number=number
    if number>len(self.contents):
      return []
    else:
      for i in range(number):
        choice=random.choice(self.contents)
        self.drawn.append(self.contents[self.contents.index(choice)])
        del self.contents[self.contents.index(choice)]
    self.holder=copy.deepcopy(self.drawn)
    return self.holder
    
      
def experiment(hat, expected_balls, num_balls_drawn, num_experiments):
  counter=0
  success=0
  expKeys=expected_balls.keys()
  if hat.draw(num_balls_drawn)==[]:
    return 1.0
  for j in range(num_experiments):
    choice=hat.draw(num_balls_drawn)
    for i in range(len(expKeys)):
      if choice.count(list(expKeys)[i])>=expected_balls[list(expKeys)[i]]:
        counter+=1
      else:
        pass
    if counter==len(expKeys):
      success+=1
    counter=0
  return success/num_experiments