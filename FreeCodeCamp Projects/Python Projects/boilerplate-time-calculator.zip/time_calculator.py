def add_time(start, duration,day=False):
  days=["sunday","monday","tuesday","wednesday","thursday","friday","saturday"]
  dayValue=False
  dayCounter=0
  if day==False:
    pass
  else:
    day=day.lower()
    dayValue=days.index(day)
  num1=0
  num2=0
  total=0
  endNum=[0,0,"AM"]
  start=start.split(":")
  start[1]=start[1].split(" ")
  start[0]=int(start[0])
  start[1][0]=int(start[1][0])
  if start[1][1]=="PM":
    start[0]+=12
  num1=start[0]*60+start[1][0]
  duration=duration.split(":")
  num2=int(duration[0])*60+int(duration[1])
  total=num1+num2
  while total>=1440:
    total-=1440
    dayCounter+=1
  while total>=60:
    total-=60
    endNum[0]+=1
  endNum[1]=total
  if endNum[0]==12:
    endNum[2]="PM"
  if endNum[0]>12:
    endNum[2]="PM"
    endNum[0]-=12
  if endNum[0]==0 and endNum[2]=="AM":
    sentence="12:"
  else:
    sentence=str(endNum[0])+":"
  if len(str(endNum[1]))==1:
    sentence+="0"+str(endNum[1])+" "+endNum[2]
  else:
    sentence+=str(endNum[1])+" "+endNum[2]
  if day!=False:
    dayValue+=dayCounter
    dayValue=dayValue % 7
    dayValue=days[dayValue]
    sentence+=", "+dayValue[0].upper()+dayValue[1:]
  if dayCounter==0:
    return sentence
  elif dayCounter==1:
    sentence+= " (next day)"
  elif dayCounter>1:
    sentence+= " ("+str(dayCounter)+ " days later)"
  print(sentence)
  return sentence